<?php

namespace App\Http\Controllers\Instructor;

use App\Http\Controllers\Controller;
use App\Models\Bundle;
use App\Models\BundleCourse;
use App\Models\CartManagement;
use App\Models\Course;
use App\Models\Wishlist;
use App\Traits\General;
use App\Traits\ImageSaveTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class BundleCourseController extends Controller
{
    use General, ImageSaveTrait;
    public function index()
    {
        $data['title'] = 'Bundle Courses';
        $data['navBundleCourseActiveClass'] = 'active';
        $data['bundles'] = Bundle::whereUserId(Auth::user()->id)->paginate();

        return view('instructor.bundle-course.index')->with($data);
    }

    public function createStepOne()
    {
        $data['title'] = 'Create Bundle Courses';
        $data['navBundleCourseActiveClass'] = 'active';

        return view('instructor.bundle-course.create-step-1')->with($data);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|max:255',
            'overview' => 'required',
            'price' => 'required',
            'image' => 'required|dimensions:min_width=575,min_height=450,max_width=575,max_height=450',
        ]);

        $bundle = new Bundle();
        $bundle->name = $request->name;
        $bundle->slug = Str::slug($request->name);
        $bundle->overview = $request->overview;
        $bundle->price = $request->price;
        $bundle->status = $request->status;
        $bundle->image = $request->image ? $this->saveImage('bundle', $request->image, null, null) :   null;
        $bundle->save();

        $this->showToastrMessage('success', 'Bundle created successfully');
        return redirect()->route('instructor.bundle-course.createStepTwo', $bundle->uuid);
    }

    public function createEditStepTwo($uuid)
    {
        $data['title'] = 'Add/Remove Bundle Course';
        $data['navBundleCourseActiveClass'] = 'active';
        $data['bundle'] = Bundle::where('uuid', $uuid)->firstOrFail();
        $data['courses'] = Course::whereUserId(Auth::user()->id)->active()->paginate();
        $data['bundleCourses'] = BundleCourse::where('bundle_id', $data['bundle']->id)->get();
        $data['alreadyAddedBundleCourseIds'] =  BundleCourse::where('bundle_id', $data['bundle']->id)->pluck('course_id')->toArray();
        $data['totalCourses'] = BundleCourse::where('bundle_id', $data['bundle']->id)->count();

        return view('instructor.bundle-course.create-edit-step-2')->with($data);
    }

    public function editStepOne($uuid)
    {
        $data['title'] = 'Update Bundle Courses';
        $data['navBundleCourseActiveClass'] = 'active';
        $data['bundle'] = Bundle::where('uuid', $uuid)->firstOrFail();

        return view('instructor.bundle-course.edit-step-1')->with($data);
    }

    public function update(Request $request, $uuid)
    {
        $request->validate([
            'name' => 'required|max:255',
            'overview' => 'required',
            'price' => 'required',
            'image' => 'dimensions:min_width=575,min_height=450,max_width=575,max_height=450'
        ]);

        $bundle = Bundle::where('uuid', $uuid)->firstOrfail();
        $bundle->name = $request->name;
        $bundle->slug = Str::slug($request->name);
        $bundle->overview = $request->overview;
        $bundle->price = $request->price;
        $bundle->status = $request->status;
        $bundle->image = $request->image ? $this->updateImage('bundle', $request->image, $bundle->image, null, null) :   $bundle->image;
        $bundle->save();

        $this->showToastrMessage('success', 'Bundle updated successfully');
        return redirect()->route('instructor.bundle-course.createStepTwo', $uuid);
    }


    public function addBundleCourse(Request $request)
    {
        $currentBundleCourse = BundleCourse::where('bundle_id', $request->bundle_id)->where('course_id', $request->course_id)->first();
        if ($currentBundleCourse){
            return response()->json([
                'status' => '409',
                'msg' => 'Already added in bundle list!',
            ]);
        }

        $bundleCourse = new BundleCourse();
        $bundleCourse->course_id = $request->course_id;
        $bundleCourse->bundle_id = $request->bundle_id;
        $bundleCourse->save();

        $totalCourses = BundleCourse::where('bundle_id', $request->bundle_id)->count();

        return response()->json([
            'status' => '200',
            'msg' => 'Course Added in bundle list.',
            'totalCourses' => $totalCourses,
            'course_id' => $request->course_id
        ]);
    }

    public function removeBundleCourse(Request $request)
    {
        $bundleCourse = BundleCourse::where('bundle_id', $request->bundle_id)->where('course_id', $request->course_id)->first();
        if ($bundleCourse){
            $bundleCourse->delete();

            $totalCourses = BundleCourse::where('bundle_id', $request->bundle_id)->count();

            return response()->json([
                'status' => '200',
                'msg' => 'Course remove from bundle list.',
                'totalCourses' => $totalCourses,
                'course_id' => $request->course_id
            ]);
        }

        return response()->json([
            'status' => '404',
            'msg' => 'Course not found in bundle list!',
        ]);
    }

    public function delete($uuid)
    {
        $bundle = Bundle::where('uuid', $uuid)->firstOrfail();
        $this->deleteFile($bundle->image);
        //Start:: Delete this bundle Wishlist, CartManagement & BundleCourse
        Wishlist::where('bundle_id', $bundle->id)->delete();
        CartManagement::where('bundle_id', $bundle->id)->delete();
        BundleCourse::where('bundle_id', $bundle->id)->delete();
        //End:: Delete this bundle wishList and addToCart
        $bundle->delete();

        $this->showToastrMessage('success', 'Bundle deleted successfully');
        return redirect()->back();
    }

}
